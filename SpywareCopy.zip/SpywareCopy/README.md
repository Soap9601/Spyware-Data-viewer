# AutoHackingUsb

In this tutorial I show you my usb password recovery tool + keylogger.

For educational purposes only.

Extract the USBhack1.0.zip on a usb stick. (download in description)

For getting the .\Files\passwords.txt and starting the keylogger just start Start.bat

Since the Password recovery tool Lasagne is supported now at .\results\credentials you will find Passwords too.
https://github.com/AlessandroZ/LaZagne

You can remove the usb now, keyylogger will run in background.

If you want the .\Files\Keyloggs.txt put your usb stick back in and start get kellogs.bat

For easier acess you could put the extracted zip in a folder and make a link.
